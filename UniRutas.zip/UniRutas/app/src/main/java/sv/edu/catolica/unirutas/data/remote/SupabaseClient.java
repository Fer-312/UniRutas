package sv.edu.catolica.unirutas.data.remote;

import sv.edu.catolica.unirutas.utils.Constants;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import java.util.concurrent.TimeUnit;

public class SupabaseClient {
    private static SupabaseApi instance;
    private static String authToken;
    public static SupabaseApi getInstance() {
        if (instance == null) {
            // Interceptor para logging
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BODY);

            // Cliente HTTP con headers
            OkHttpClient okHttpClient = new OkHttpClient.Builder()
                    .addInterceptor(chain -> {
                        Request original = chain.request();

                        // DEBUG: Imprimir la URL y headers para verificar
                        System.out.println("URL: " + original.url());
                        System.out.println("API Key: " + Constants.SUPABASE_ANON_KEY);

                        Request.Builder requestBuilder = original.newBuilder()
                                .header("apikey", Constants.SUPABASE_ANON_KEY)
                                .header("Authorization", "Bearer " + Constants.SUPABASE_ANON_KEY)
                                .header("Content-Type", "application/json")
                                .header("Prefer", "return=representation");

                        Request request = requestBuilder.build();
                        return chain.proceed(request);
                    })
                    .addInterceptor(logging)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .build();

            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(Constants.BASE_URL)
                    .client(okHttpClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

            instance = retrofit.create(SupabaseApi.class);
        }
        return instance;
    }
}
package sv.edu.catolica.unirutas.utils;

public class Constants {
    public static final String SUPABASE_URL = "https://iayjkltthotvnmugxhsq.supabase.co";
    public static final String SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlheWprbHR0aG90dm5tdWd4aHNxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjA3MTc1MzAsImV4cCI6MjA3NjI5MzUzMH0.n6HtvFdN7C2Mn-q35YslsaAUlHpMzfPSJ2X0USuvIVs";
    public static final String BASE_URL = SUPABASE_URL + "/rest/v1/";

    // Estados comunes
    public static final int ESTADO_ACTIVO = 1;
    public static final int ESTADO_INACTIVO = 2;

    // Tipos de usuario
    public static final int TIPO_ESTUDIANTE = 1;
    public static final int TIPO_MOTORISTA = 2;
    public static final int TIPO_ORGANIZACION = 3;

    // Prefer headers para Supabase
    public static final String PREFER_RETURN_REPRESENTATION = "return=representation";
    public static final String PREFER_RETURN_MINIMAL = "return=minimal";
}
package sv.edu.catolica.unirutas.data.repository;

import android.content.Context;
import android.content.SharedPreferences;
import sv.edu.catolica.unirutas.data.remote.SupabaseApi;
import sv.edu.catolica.unirutas.data.remote.SupabaseClient;
import sv.edu.catolica.unirutas.data.model.AuthResponse;
import sv.edu.catolica.unirutas.data.model.LoginRequest;
import sv.edu.catolica.unirutas.data.model.RegisterRequest;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AuthRepository {
    private SupabaseApi api;
    private SharedPreferences prefs;
    private static final String PREFS_NAME = "AuthPrefs";
    private static final String KEY_ACCESS_TOKEN = "access_token";
    private static final String KEY_REFRESH_TOKEN = "refresh_token";

    public AuthRepository(Context context) {
        this.api = SupabaseClient.getInstance();
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        // Cargar token al iniciar
        loadStoredToken();
    }

    public interface AuthCallback {
        void onSuccess(String message);
        void onError(String error);
    }

    // LOGIN
    public void login(String email, String password, AuthCallback callback) {
        LoginRequest loginRequest = new LoginRequest(email, password);

        api.login(loginRequest).enqueue(new Callback<AuthResponse>() {
            @Override
            public void onResponse(Call<AuthResponse> call, Response<AuthResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    AuthResponse authResponse = response.body();

                    // Guardar tokens
                    saveTokens(authResponse.getAccessToken(), authResponse.getRefreshToken());

                    // Actualizar cliente con nuevo token
                    SupabaseClient.setAuthToken(authResponse.getAccessToken());  // ← ASÍ ES CORRECTO

                    callback.onSuccess("Login exitoso");
                } else {
                    callback.onError("Error en login: " + response.code() + " - " + response.message());
                }
            }

            @Override
            public void onFailure(Call<AuthResponse> call, Throwable t) {
                callback.onError("Error de conexión: " + t.getMessage());
            }
        });
    }

    // REGISTER
    public void register(String email, String password, String nombre, String apellido, AuthCallback callback) {
        RegisterRequest registerRequest = new RegisterRequest(email, password, nombre, apellido);

        api.register(registerRequest).enqueue(new Callback<AuthResponse>() {
            @Override
            public void onResponse(Call<AuthResponse> call, Response<AuthResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    callback.onSuccess("Registro exitoso. Verifica tu email.");
                } else {
                    callback.onError("Error en registro: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<AuthResponse> call, Throwable t) {
                callback.onError("Error de conexión: " + t.getMessage());
            }
        });
    }

    // LOGOUT
    public void logout(AuthCallback callback) {
        api.logout().enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                clearTokens();
                callback.onSuccess("Sesión cerrada");
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                // Limpiar tokens localmente aunque falle el logout en el servidor
                clearTokens();
                callback.onSuccess("Sesión cerrada localmente");
            }
        });
    }

    // VERIFICAR SI ESTÁ LOGUEADO
    public boolean isLoggedIn() {
        return prefs.getString(KEY_ACCESS_TOKEN, null) != null;
    }

    // GUARDAR TOKENS
    private void saveTokens(String accessToken, String refreshToken) {
        prefs.edit()
                .putString(KEY_ACCESS_TOKEN, accessToken)
                .putString(KEY_REFRESH_TOKEN, refreshToken)
                .apply();
    }

    // CARGAR TOKEN AL CLIENTE
    private void loadStoredToken() {
        String token = prefs.getString(KEY_ACCESS_TOKEN, null);
        if (token != null) {
            SupabaseClient.setAuthToken(token);
        }
    }

    // LIMPIAR TOKENS
    private void clearTokens() {
        prefs.edit()
                .remove(KEY_ACCESS_TOKEN)
                .remove(KEY_REFRESH_TOKEN)
                .apply();
        SupabaseClient.clearAuthToken();
    }

    // OBTENER TOKEN ACTUAL
    public String getAccessToken() {
        return prefs.getString(KEY_ACCESS_TOKEN, null);
    }
}
package sv.edu.catolica.unirutas.ui.main;

import android.content.res.Resources;
import android.os.Bundle;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.List;

import sv.edu.catolica.unirutas.R;
import sv.edu.catolica.unirutas.data.model.Favorito;
import sv.edu.catolica.unirutas.data.model.Ruta;
import sv.edu.catolica.unirutas.data.model.Ruta1;
import sv.edu.catolica.unirutas.data.repository.RutaRepository;

public class MainActivity extends AppCompatActivity {

    private LinearLayout containerRutasInscritas;



    private LinearLayout containerRutasFavoritas;
    private RutaRepository repository;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        containerRutasInscritas = findViewById(R.id.containerRutasInscritas);
        containerRutasFavoritas = findViewById(R.id.containerRutasFavoritas);

        repository = new RutaRepository();

        // Agregar rutas de ejemplo
        agregarRutasFavoritas();
        agregarRutasInscritas();

        //Espacio para tabs
        Resources res = getResources();

        TabHost tabControl = (TabHost) findViewById(R.id.MiTabHost);
        tabControl.setup();

        TabHost.TabSpec spec = tabControl.newTabSpec("PESO");
        spec.setContent(R.id.tab1);
        spec.setIndicator("",res.getDrawable(R.drawable.ic_home));
        tabControl.addTab(spec);

        spec = tabControl.newTabSpec("TEMP");
        spec.setContent(R.id.tab2);
        spec.setIndicator("",res.getDrawable(R.drawable.ic_bus));
        tabControl.addTab(spec);


    }
    private void agregarRutasFavoritas() {
        repository.getFavoritos(new RutaRepository.RepositoryCallback<List<Favorito>>() {
            @Override
            public void onSuccess(List<Favorito> data) {

            }

            @Override
            public void onError(String error) {

            }
        });

    }
    private void agregarRutasInscritas() {
        repository.getRutasConEstado(new RutaRepository.RepositoryCallback<List<Ruta>>() {
            @Override
            public void onSuccess(List<Ruta> listruta) {

                for (Ruta ruta: listruta) {
                    View itemView = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_ruta, containerRutasInscritas, false);
                    TextView tvRutaOrigen = itemView.findViewById(R.id.tvRutaOrigen);
                    TextView tvRutaDestino = itemView.findViewById(R.id.tvRutaDestino);
                    TextView tvHorario = itemView.findViewById(R.id.tvHorario);
                    TextView tvEstado = itemView.findViewById(R.id.tvEstado);

                    tvRutaOrigen.setText("Ruta " + ruta.getMunicipioOrigen());
                    tvRutaDestino.setText(ruta.getMunicipioDestino());
                    tvHorario.setText(String.valueOf(ruta.getHoraSalida()));
                    //Configuraciones de interfaz como color etc
                    tvEstado.setTextColor(getResources().getColor(R.color.white));
                    tvEstado.setText(ruta.getEstado().getNombre());
                    //este es el boton que abre la ruta
                    itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onRutaCardClick(ruta);
                        }
                    });

                    // Cambiar color según el estado
                    if ("Lleno".equals(ruta.getEstado().getNombre())) {
                        tvEstado.setBackgroundResource(R.drawable.bg_badge_red);
                        containerRutasInscritas.addView(itemView);

                    } else if ("Disponible".equals(ruta.getEstado().getNombre())) {
                        tvEstado.setBackgroundResource(R.drawable.bg_badge_green);
                        containerRutasInscritas.addView(itemView);
                    }



                }

            }

            @Override
            public void onError(String error) {
                
            }
        });




    }
    private void onRutaCardClick(Ruta ruta) {
        // Aquí pones la lógica cuando se pulsa una card

        Toast.makeText(this,
                "Card pulsada: " + ruta.getMunicipioOrigen() + " → " + ruta.getMunicipioDestino() +
                        "\nHora: " + ruta.getHoraSalida() +
                        "\nEstado: " + ruta.getEstado().getNombre(),
                Toast.LENGTH_LONG).show();
    }


}
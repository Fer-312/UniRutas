package sv.edu.catolica.unirutas.data.model;

import com.google.gson.annotations.SerializedName;

public class Estudiante {
    @SerializedName("id_estudiante")
    private int idEstudiante;

    @SerializedName("id_usuario")
    private Integer idUsuario;

    @SerializedName("carnet")
    private String carnet;

    @SerializedName("universidad")
    private String universidad;

    // Constructor
    public Estudiante() {}

    // Getters y Setters
    public int getIdEstudiante() { return idEstudiante; }
    public void setIdEstudiante(int idEstudiante) { this.idEstudiante = idEstudiante; }

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }

    public String getCarnet() { return carnet; }
    public void setCarnet(String carnet) { this.carnet = carnet; }

    public String getUniversidad() { return universidad; }
    public void setUniversidad(String universidad) { this.universidad = universidad; }
}
package sv.edu.catolica.unirutas.data.model;

import com.google.gson.annotations.SerializedName;
import java.sql.Timestamp;
import java.math.BigDecimal;

public class Inscripcion {
    @SerializedName("id_inscripcion")
    private int idInscripcion;

    @SerializedName("id_estudiante")
    private Integer idEstudiante;

    @SerializedName("id_ruta")
    private Integer idRuta;

    @SerializedName("fecha_inscripcion")
    private Timestamp fechaInscripcion;

    @SerializedName("estado_inscripcion")
    private Boolean estadoInscripcion;

    @SerializedName("tarifa_pagada")
    private BigDecimal tarifaPagada;

    @SerializedName("fecha_asistencia")
    private Timestamp fechaAsistencia;

    @SerializedName("estado_asistencia")
    private Boolean estadoAsistencia;

    @SerializedName("codigo_qr")
    private String codigoQr;

    // Constructor
    public Inscripcion() {}

    // Getters y Setters
    public int getIdInscripcion() { return idInscripcion; }
    public void setIdInscripcion(int idInscripcion) { this.idInscripcion = idInscripcion; }

    public Integer getIdEstudiante() { return idEstudiante; }
    public void setIdEstudiante(Integer idEstudiante) { this.idEstudiante = idEstudiante; }

    public Integer getIdRuta() { return idRuta; }
    public void setIdRuta(Integer idRuta) { this.idRuta = idRuta; }

    public Timestamp getFechaInscripcion() { return fechaInscripcion; }
    public void setFechaInscripcion(Timestamp fechaInscripcion) { this.fechaInscripcion = fechaInscripcion; }

    public Boolean getEstadoInscripcion() { return estadoInscripcion; }
    public void setEstadoInscripcion(Boolean estadoInscripcion) { this.estadoInscripcion = estadoInscripcion; }

    public BigDecimal getTarifaPagada() { return tarifaPagada; }
    public void setTarifaPagada(BigDecimal tarifaPagada) { this.tarifaPagada = tarifaPagada; }

    public Timestamp getFechaAsistencia() { return fechaAsistencia; }
    public void setFechaAsistencia(Timestamp fechaAsistencia) { this.fechaAsistencia = fechaAsistencia; }

    public Boolean getEstadoAsistencia() { return estadoAsistencia; }
    public void setEstadoAsistencia(Boolean estadoAsistencia) { this.estadoAsistencia = estadoAsistencia; }

    public String getCodigoQr() { return codigoQr; }
    public void setCodigoQr(String codigoQr) { this.codigoQr = codigoQr; }
}